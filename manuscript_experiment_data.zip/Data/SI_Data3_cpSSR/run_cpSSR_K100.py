#!/usr/bin/env python3
"""Reproduce the cpSSR (Cyanidiales SSR9v2) Ladderpath analysis reported in
Section 3.3.1 and Figure 3.3.1 of the main paper, using lp_developers v2.0.18
with K=100 mean-distance averaging.

Pipeline:
  1) Load 6 strain sequences (5562, 5578, 5580, 5602, 5612, 5633) from
     SSR9v2.fasta.
  2) K=100 independent get_ladderpath -> Dice + Jaccard distance tables.
  3) Per-pair mean over the K=100 runs.
  4) Build NJ and UPGMA on the mean matrices via
     ladderpath_tools.phylo.phylo.
  5) Unrooted nRF between each LP tree and each provided comparator
     (MP, NJ, UPGMA, BI, ML).

Expected unrooted nRF vs MP/NJ/UPGMA (which all agree on the same topology):
    Dice_LPN     0.333
    Dice_LPU     0.000
    Jaccard_LPN  0.333
    Jaccard_LPU  0.000
"""

import csv
import sys
import time
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import numpy as np

LP_DEVELOPERS_ROOT = "/Document/results"
sys.path.insert(0, LP_DEVELOPERS_ROOT)

from lp_developers import ladderpath as lp
from lp_developers.ladderpath_tools import phylo as lp_phylo
from lp_developers.ladderpath_tools import species_distance as lp_sd
from Bio import SeqIO
from ete3 import Tree

HERE = Path(__file__).resolve().parent
FASTA = HERE / "SSR9v2.fasta"
K = 100

COMPARATORS = {
    "MP":    HERE / "cpSSR_MP.newick",
    "NJ":    HERE / "cpSSR_NJ.newick",
    "UPGMA": HERE / "cpSSR_UPGMA.newick",
    "BI":    HERE / "cpSSR_BI.newick",
    "ML":    HERE / "cpSSR_ML.newick",
}


def clean_seq(seq):
    return "".join(ch for ch in str(seq).upper() if ch not in {"-", " ", "\t", "\n", "\r"})


def main():
    records = list(SeqIO.parse(str(FASTA), "fasta"))
    labels = [r.id for r in records]
    seqs = [clean_seq(r.seq) for r in records]
    N = len(seqs)
    print(f"cpSSR: N={N}, length range {min(map(len, seqs))}-{max(map(len, seqs))}, labels={labels}")

    target_ids = [-(i + 1) for i in range(N)]
    species_info = {f"sp{i+1}": (labels[i], [target_ids[i]]) for i in range(N)}

    print(f"running K={K} LP iterations...")
    dice_runs, jacc_runs, lp_idx = [], [], []
    t0 = time.time()
    for k in range(1, K + 1):
        lpjson = lp.get_ladderpath(seqs, save_file_name=None, show_version=False, gpu_mode=0)
        lp_idx.append(lpjson["ladderpath-index"])
        d, nm, _ = lp_sd.get_distance_table(lpjson, species_info, method="dice", verbose=False)
        j, _, _ = lp_sd.get_distance_table(lpjson, species_info, method="jaccard", verbose=False)
        dice_runs.append({kk: max(0.0, float(v)) for kk, v in d.items()})
        jacc_runs.append({kk: max(0.0, float(v)) for kk, v in j.items()})
        if k == 1 or k % 25 == 0 or k == K:
            print(f"  run {k:>3d}/{K}: LP={lpjson['ladderpath-index']}, elapsed {time.time()-t0:.1f}s")

    pair_keys = list(dice_runs[0].keys())
    dice_mean = {pk: float(np.mean([r[pk] for r in dice_runs])) for pk in pair_keys}
    jacc_mean = {pk: float(np.mean([r[pk] for r in jacc_runs])) for pk in pair_keys}
    name_map = {int(k): v for k, v in nm.items()}

    cv = float(np.std(lp_idx, ddof=1) / np.mean(lp_idx))
    print(f"K={K} done; LP-index mean={np.mean(lp_idx):.2f}, CV={cv:.4f}\n")

    specs = [
        ("Dice_LPN",    dice_mean, "nj"),
        ("Dice_LPU",    dice_mean, "upgma"),
        ("Jaccard_LPN", jacc_mean, "nj"),
        ("Jaccard_LPU", jacc_mean, "upgma"),
    ]

    comp_trees = {n: Tree(str(p), format=1) for n, p in COMPARATORS.items()}

    print("unrooted nRF (LP vs each comparator):")
    for label, table, algo in specs:
        tmp = HERE / f"_tmp_{label}.newick"
        if tmp.exists(): tmp.unlink()
        lp_phylo.phylo(table, name_map, method=algo, outgroup_name=None,
                       newick_file_name=str(tmp), fig_file_name=None,
                       show_plot=False, verbose=False)
        q = Tree(str(tmp), format=1)
        row = []
        for cname, ct in comp_trees.items():
            rf, max_rf, *_ = ct.robinson_foulds(q, unrooted_trees=True)
            nrf = rf / max_rf if max_rf else 0.0
            row.append(f"vs_{cname}={nrf:.3f}")
        print(f"  {label:<12}: " + ", ".join(row))
        tmp.unlink()


if __name__ == "__main__":
    main()
