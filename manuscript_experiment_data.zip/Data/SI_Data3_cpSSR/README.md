# SI Data 3 — Cyanidiales cpSSR (SSR9 variant 2) dataset

This bundle contains the input sequences, comparator trees, runner script, and Ladderpath tree outputs for the cpSSR empirical analysis reported in Section 3.3.1 and Figure 3.3.1 of the main paper.

## Files

| file | description |
|------|-------------|
| `SSR9v2.fasta` | 6 *Cyanidioschyzon merolae* strains (5562, 5578, 5580, 5602, 5612, 5633), 675–678 bp DNA each. Repeat-rich chloroplast SSR marker from Toplin et al. (2008). |
| `cpSSR_MP.newick`, `cpSSR_NJ.newick`, `cpSSR_UPGMA.newick`, `cpSSR_BI.newick`, `cpSSR_ML.newick` | Comparator trees from the original empirical pipeline. MP, NJ, and UPGMA all give the same topology in this dataset. |
| `cpSSR_Dice_LPN.newick`, `cpSSR_Dice_LPU.newick`, `cpSSR_Jaccard_LPN.newick`, `cpSSR_Jaccard_LPU.newick` | LP trees built from the K=100 mean Dice and Jaccard distance matrices. |
| `cpSSR_pair_distances_K100.csv` | Per-pair Dice and Jaccard mean ± SE over K=100 independent LP runs. |
| `cpSSR_nRF_summary.csv` | Unrooted nRF of each LP tree vs MP (representative of MP=NJ=UPGMA). |
| `cpSSR_full_nRF.csv` | Full nRF matrix: each LP tree vs each comparator (MP, NJ, UPGMA, BI, ML). |
| `run_cpSSR_K100.py` | One-file runner that reproduces all of the above from `SSR9v2.fasta` and the comparator Newick files. |

## Reproducing the cpSSR nRF values

```
python3 run_cpSSR_K100.py
```

Expected output (matches Section 3.3.1 of the main paper):

```
Dice_LPN    : vs_MP=0.333, vs_NJ=0.333, vs_UPGMA=0.333, vs_BI=0.600, vs_ML=0.667
Dice_LPU    : vs_MP=0.000, vs_NJ=0.000, vs_UPGMA=0.000, vs_BI=0.200, vs_ML=0.333
Jaccard_LPN : vs_MP=0.333, vs_NJ=0.333, vs_UPGMA=0.333, vs_BI=0.600, vs_ML=0.667
Jaccard_LPU : vs_MP=0.000, vs_NJ=0.000, vs_UPGMA=0.000, vs_BI=0.200, vs_ML=0.333
```

LPD+UPGMA and LPJ+UPGMA agree exactly with MP, NJ, and UPGMA (nRF = 0.000) and stay close to BI (nRF = 0.200). LPD+NJ and LPJ+NJ give a one-NNI-different topology (nRF = 0.333).

## Reproducibility note

The cpSSR result is robust to single-LP-run variability: 100 independent runs without averaging give the same tree topology for each method, with per-pair distance SE ≤ 3×10⁻⁴.
