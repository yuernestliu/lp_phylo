# SI Data 7 — Standard divergence-gradient simulation benchmark (phase3, manuscript A1–A5)

This bundle contains raw simulation inputs, LP outputs, and aggregated tables for the standard substitutional benchmark reported in main paper Section 3.2.1 and SI tables tab:divergence-gradient and tab:phase3A-stat-summary.

## Condition labels

The per-rep directories and CSVs use labels **A1–A5**, which match the manuscript labels (no remapping). A1 corresponds to the lowest tree scale (~0.02 substitutions per site) and A5 to the highest (~0.50).

## Layout

```
SI_Data7_sim_phase3/
├── README.md                                   (this file)
├── nRF_phase3_rooted.csv                       # per-rep rooted nRF, all methods × all 150 reps
├── summary_means_phase3_rooted_K3.csv          # per condition × method: mean, SD, median, 95% CI
├── stats_LP_vs_others_phase3_rooted_K3.csv     # paired Wilcoxon LDice+NJ vs each competitor
├── figure_phase3_bar_rooted_K3.png             # the bar plot (reproduced as Fig. 3.2.1 in main)
├── raw/                                        # raw simulation inputs (5 conditions × 30 reps = 150 dirs)
│   ├── A1_rep01/
│   │   ├── sim_tree.nwk                        #   the reference (ground-truth) tree for this replicate
│   │   └── unaligned.fasta                     #   20 simulated 4-kb DNA sequences
│   ├── A1_rep02/ ... A5_rep30/
└── LP_K3/                                      # LP outputs from K=3 mean-distance recomputation
    ├── A1_rep01/
    │   ├── dice_dist_K3.csv                    #   K=3 mean Dice distance matrix
    │   ├── dice_nj_K3.nwk                      #   LDice+NJ tree
    │   ├── dice_upgma_K3.nwk                   #   LDice+UPGMA tree
    │   ├── jaccard_dist_K3.csv                 #   K=3 mean Jaccard distance matrix
    │   ├── jaccard_nj_K3.nwk                   #   LJaccard+NJ tree
    │   └── jaccard_upgma_K3.nwk                #   LJaccard+UPGMA tree
    └── A1_rep02/ ... A5_rep30/
```

## Reproducing the table values

The shared Python scripts in `../sim_scripts/` produce these outputs. Note that phase3 uses a dedicated `task2_phase3_rooted_nrf.py` (instead of the generic `task2_rooted_nrf.py`) because phase3 stores ML/MP/BI inside per-rep `*_work/` subdirectories rather than as top-level `ml.nwk`/`mp.nwk`/`bi.nwk` files; the phase3 task2 script extracts those trees and additionally computes NJ/UPGMA from `iqtree.mldist` and CVTree from `unaligned.fasta` (k=6 cosine) on the fly.

**What's not included**: the per-rep `*_work/` intermediate directories (ML/MP/BI run artefacts) and the MAFFT alignment, for bundle-size reasons. Re-running phase3 from scratch requires regenerating those via IQ-TREE / MrBayes / MAFFT on `raw/<rep>/unaligned.fasta`.

## Reproducibility note

LP analyses used the CPU implementation of `lp_phylo` (ladderpath.py v2.0.18) with K=3 mean distance averaging. K=3 was chosen instead of K=10 because the 4-kb root sequences made K=10 prohibitively slow on a 16 GB Mac mini (K=3 took ~43 h end-to-end). The K=3 mean is still well within the LP variability bound (CV ≤ 0.5%) for the nRF precision reported.
