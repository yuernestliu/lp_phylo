# SI Data 6 — Block-translocation simulation benchmark (exp3i, manuscript B1–B6)

This bundle contains raw simulation inputs, LP outputs, and aggregated tables for the block-translocation alignment-difficulty benchmark reported in main paper Section 3.2.2 and SI tables tab:align-difficulty-full and tab:sim-stat-summary.

## Condition labels

The per-rep directories and CSVs use the original simulation labels **A1–A6**, which correspond one-to-one to the manuscript labels **B1–B6** (in order: B1 = 0 translocation events per branch, B6 = 20 events per branch with the largest block sizes).

## Layout

```
SI_Data6_sim_exp3i/
├── README.md                                   (this file)
├── nRF_exp3i_rooted.csv                        # per-rep rooted nRF, all methods × all 180 reps
├── summary_means_exp3i_rooted_K10.csv          # per condition × method: mean, SD, median, 95% CI
├── stats_LP_vs_others_exp3i_rooted_K10.csv     # paired Wilcoxon LDice+NJ vs each competitor
├── figure_exp3i_bar_rooted_K10.png/.pdf        # the bar plot (reproduced as Fig. 3.2.2 in main)
├── run_lp_k10.log                              # wall-clock log of the K=10 LP recomputation pass
├── raw/                                        # raw simulation inputs (6 conditions × 30 reps = 180 dirs)
│   ├── A1_rep01/
│   │   ├── true_tree.nwk                       #   the reference (ground-truth) tree for this replicate
│   │   └── unaligned.fasta                     #   30 simulated 1.5-kb DNA sequences
│   ├── A1_rep02/ ... A6_rep30/
└── LP_K10/                                     # LP outputs from K=10 mean-distance recomputation
    ├── A1_rep01/
    │   ├── dice_dist_K10.csv                   #   K=10 mean Dice distance matrix
    │   ├── dice_nj_K10.nwk                     #   LDice+NJ tree
    │   ├── dice_upgma_K10.nwk                  #   LDice+UPGMA tree
    │   ├── jaccard_dist_K10.csv                #   K=10 mean Jaccard distance matrix
    │   ├── jaccard_nj_K10.nwk                  #   LJaccard+NJ tree
    │   └── jaccard_upgma_K10.nwk               #   LJaccard+UPGMA tree
    └── A1_rep02/ ... A6_rep30/
```

## Reproducing the table values

The shared Python scripts in `../sim_scripts/` follow the same workflow as SI Data 5; see `../SI_Data5_sim_exp1/README.md` for the script descriptions. The condition mapping (A → B) is applied automatically inside `task4_si_tables.py` when emitting LaTeX rows.

**What's not included**: alignment-based comparator method trees and the MAFFT alignment, for the same reason as SI Data 5 (bundle size).

## Reproducibility note

LP analyses used the CPU implementation of `lp_phylo` (ladderpath.py v2.0.18) with K=10 mean distance averaging. As substitution-driven alignment becomes unreliable at higher B values, this benchmark is the test of choice for whether structural distance can recover signal where MAFFT-dependent pipelines lose it.
