# SI Data 5 — Indel-dominated simulation benchmark (exp1, manuscript C1–C5)

This bundle contains raw simulation inputs, LP outputs, and aggregated tables for the indel-dominated benchmark reported in main paper Section 3.2.3 and SI tables tab:indel-dominated-full and tab:indel-stat-summary.

## Condition labels

The per-rep directories and CSVs use the original simulation labels **J1–J5**, which correspond one-to-one to the manuscript labels **C1–C5** (in order: C1 = lowest indel rate, C5 = highest).

## Layout

```
SI_Data5_sim_exp1/
├── README.md                                  (this file)
├── nRF_exp1_rooted.csv                        # per-rep rooted nRF, all methods × all 150 reps
├── summary_means_exp1_rooted_K10.csv          # per condition × method: mean, SD, median, 95% CI
├── stats_LP_vs_others_exp1_rooted_K10.csv     # paired Wilcoxon LDice+NJ vs each competitor
├── figure_exp1_bar_rooted_K10.png/.pdf        # the bar plot (reproduced as Fig. 3.2.3 in main)
├── run_lp_k10.log                             # wall-clock log of the K=10 LP recomputation pass
├── raw/                                       # raw simulation inputs (5 conditions × 30 reps = 150 dirs)
│   ├── J1_rep01/
│   │   ├── true_tree.nwk                      #   the reference (ground-truth) tree for this replicate
│   │   └── unaligned.fasta                    #   20 simulated 2-kb DNA sequences
│   ├── J1_rep02/ ... J5_rep30/
└── LP_K10/                                    # LP outputs from K=10 mean-distance recomputation
    ├── J1_rep01/
    │   ├── dice_dist_K10.csv                  #   K=10 mean Dice distance matrix
    │   ├── dice_nj_K10.nwk                    #   LDice+NJ tree
    │   ├── dice_upgma_K10.nwk                 #   LDice+UPGMA tree
    │   ├── jaccard_dist_K10.csv               #   K=10 mean Jaccard distance matrix
    │   ├── jaccard_nj_K10.nwk                 #   LJaccard+NJ tree
    │   └── jaccard_upgma_K10.nwk              #   LJaccard+UPGMA tree
    └── J1_rep02/ ... J5_rep30/
```

## Reproducing the table values

The shared Python scripts that produced the LP outputs, aggregated CSVs, and figure live in `../sim_scripts/`:

1. `run_lp_k10.py` — re-runs the K=10 LP recomputation per replicate from `raw/<rep>/unaligned.fasta`, writes `LP_K10/<rep>/*`.
2. `task2_rooted_nrf.py` — re-roots every method tree (LP + ML/BI/MP/NJ/UPGMA/CVTree) on the outgroup chosen as the alphabetically first leaf of the smaller side of the reference tree's root split, then computes rooted nRF. Writes `nRF_exp1_rooted.csv`.
3. `task3_bars_and_stats.py` — produces `figure_exp1_bar_rooted_K10.png/.pdf`, `summary_means_*.csv`, and `stats_LP_vs_others_*.csv`.
4. `task4_si_tables.py` — emits the LaTeX rows for SI tables tab:indel-dominated-full and tab:indel-stat-summary.

**What's not included**: the alignment-based comparator method trees (`ml.nwk`, `bi.nwk`, `mp.nwk`, `classical_nj.nwk`, `classical_upgma.nwk`, `cvtree_nj.nwk`) and the MAFFT alignment (`aligned.fasta`) were not included to keep the bundle small. Anyone re-running the full pipeline from `raw/<rep>/unaligned.fasta` will need MAFFT v7.526, IQ-TREE2 2.4.0, MrBayes 3.2.7a, BioPython v1.87, and DendroPy v5.0.8 — see the main Methods section for exact parameters.

## Reproducibility note

LP analyses used the CPU implementation of `lp_phylo` (ladderpath.py v2.0.18) with K=10 mean distance averaging via `get_distance_table_average_from_seqs(..., n_runs=10)`. The CPU path's run-to-run CV is ≤ 0.5% per species pair, so K=10 is sufficient to suppress randomness below the precision of the reported nRF values.
