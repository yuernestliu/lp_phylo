#!/usr/bin/env python3
"""Reproduce the cytochrome c (Fitch & Margoliash 1967) Ladderpath analysis
reported in Section 3.3.3 of the main paper, using lp_developers v2.0.18
with K=100 mean-distance averaging.

Pipeline:
  1) Load 20 unaligned protein sequences from fitch_20.fasta.
  2) K=100 independent get_ladderpath -> Dice + Jaccard distance tables.
  3) Per-pair mean over the K=100 runs.
  4) Build NJ and UPGMA on the mean matrices via
     ladderpath_tools.phylo.phylo.
  5) Apply the FASTA-name → Fitch-1967-name remap to the LP trees and
     compute unrooted nRF against fitch_1967_reference.newick.

Expected unrooted nRF (matches main-paper Section 3.3.3 table):
    Dice_LPN     0.235
    Dice_LPU     0.176
    Jaccard_LPN  0.176
    Jaccard_LPU  0.176

Reference uses 1967 convention names; FASTA uses modern names. A small
hand mapping bridges the two.
"""

import csv
import re
import sys
import time
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import numpy as np

LP_DEVELOPERS_ROOT = "/Document/results"
sys.path.insert(0, LP_DEVELOPERS_ROOT)

from lp_developers import ladderpath as lp
from lp_developers.ladderpath_tools import phylo as lp_phylo
from lp_developers.ladderpath_tools import species_distance as lp_sd
from Bio import SeqIO
from ete3 import Tree

HERE = Path(__file__).resolve().parent
FASTA = HERE / "fitch_20.fasta"
REF = HERE / "fitch_1967_reference.newick"
K = 100

NAME_MAP = {
    "Human": "Man",
    "Rhesus_monkey": "Monkey",
    "Pekin_duck": "Duck",
    "Snapping_turtle": "Turtle",
    "Rattlesnake": "Snake",
    "Screwworm_fly": "Screw_worm",
    "Silkworm_moth": "Moth",
}


def clean_seq(seq):
    return "".join(ch for ch in str(seq).upper() if ch not in {"-", " ", "\t", "\n", "\r"})


def apply_name_map(nwk):
    out = nwk
    for src, dst in NAME_MAP.items():
        out = re.sub(rf"\b{re.escape(src)}\b", dst, out)
    return out


def main():
    records = list(SeqIO.parse(str(FASTA), "fasta"))
    labels = [r.id for r in records]
    seqs = [clean_seq(r.seq) for r in records]
    N = len(seqs)
    print(f"cytochrome c: N={N}, length range {min(map(len, seqs))}-{max(map(len, seqs))}")

    target_ids = [-(i + 1) for i in range(N)]
    species_info = {f"sp{i+1}": (labels[i], [target_ids[i]]) for i in range(N)}

    print(f"running K={K} LP iterations...")
    dice_runs, jacc_runs, lp_idx = [], [], []
    t0 = time.time()
    for k in range(1, K + 1):
        lpjson = lp.get_ladderpath(seqs, save_file_name=None, show_version=False, gpu_mode=0)
        lp_idx.append(lpjson["ladderpath-index"])
        d, nm, _ = lp_sd.get_distance_table(lpjson, species_info, method="dice", verbose=False)
        j, _, _ = lp_sd.get_distance_table(lpjson, species_info, method="jaccard", verbose=False)
        dice_runs.append({kk: max(0.0, float(v)) for kk, v in d.items()})
        jacc_runs.append({kk: max(0.0, float(v)) for kk, v in j.items()})
        if k == 1 or k % 25 == 0 or k == K:
            print(f"  run {k:>3d}/{K}: LP={lpjson['ladderpath-index']}, elapsed {time.time()-t0:.1f}s")

    pair_keys = list(dice_runs[0].keys())
    dice_mean = {pk: float(np.mean([r[pk] for r in dice_runs])) for pk in pair_keys}
    jacc_mean = {pk: float(np.mean([r[pk] for r in jacc_runs])) for pk in pair_keys}
    name_map = {int(k): v for k, v in nm.items()}

    cv = float(np.std(lp_idx, ddof=1) / np.mean(lp_idx))
    print(f"K={K} done; LP-index mean={np.mean(lp_idx):.2f}, CV={cv:.4f}\n")

    ref = Tree(str(REF), format=1)
    max_rf = 2 * (N - 3)

    specs = [
        ("Dice_LPN",    dice_mean, "nj"),
        ("Dice_LPU",    dice_mean, "upgma"),
        ("Jaccard_LPN", jacc_mean, "nj"),
        ("Jaccard_LPU", jacc_mean, "upgma"),
    ]
    print(f"unrooted nRF vs Fitch 1967 reference (max_rf={max_rf}):")
    for label, table, algo in specs:
        tmp = HERE / f"_tmp_{label}.newick"
        if tmp.exists(): tmp.unlink()
        lp_phylo.phylo(table, name_map, method=algo, outgroup_name=None,
                       newick_file_name=str(tmp), fig_file_name=None,
                       show_plot=False, verbose=False)
        nwk = tmp.read_text().strip()
        nwk_remap = apply_name_map(nwk)
        q = Tree(nwk_remap, format=1)
        rf, _max_rf, *_ = ref.robinson_foulds(q, unrooted_trees=True)
        nrf = rf / max_rf if max_rf else 0.0
        print(f"  {label:<12}: rf={rf}/{max_rf}, nRF={nrf:.6f}")
        tmp.unlink()


if __name__ == "__main__":
    main()
