# SI Data 4 — Cytochrome c (Fitch & Margoliash 1967) dataset

This bundle contains the input sequences, historical reference tree, runner script, and Ladderpath tree outputs for the cytochrome c empirical analysis reported in Section 3.3.3 of the main paper.

## Files

| file | description |
|------|-------------|
| `fitch_20.fasta` | 20 unaligned protein sequences (cytochrome c, 103–110 amino acids each), modern FASTA-name convention (Human, Rhesus_monkey, …, Candida). |
| `fitch_1967_reference.newick` | Hand-curated reference topology from Fitch & Margoliash (1967), 1967-name convention (Man, Monkey, Duck, Turtle, Snake, Screw_worm, Moth). |
| `cytc_Dice_LPN.newick`, `cytc_Dice_LPU.newick`, `cytc_Jaccard_LPN.newick`, `cytc_Jaccard_LPU.newick` | LP trees built from the K=100 mean Dice and Jaccard distance matrices. Leaves use FASTA-name convention; apply `NAME_MAP` (see `run_cytc_K100.py`) to compare against the 1967 reference. |
| `cytc_pair_distances_K100.csv` | Per-pair Dice and Jaccard mean ± SE over K=100 independent LP runs. |
| `cytc_nRF_summary.csv` | Unrooted nRF (rf, max_rf, nRF) of each LP tree against the Fitch 1967 reference. |
| `run_cytc_K100.py` | One-file runner that reproduces all of the above from `fitch_20.fasta` and `fitch_1967_reference.newick`. |

## Reproducing the cytochrome c nRF values

```
python3 run_cytc_K100.py
```

Expected output (matches Section 3.3.3 of the main paper, Table tab:cytc-nrf):

```
Dice_LPN    : rf=8/34, nRF=0.235294
Dice_LPU    : rf=6/34, nRF=0.176471
Jaccard_LPN : rf=6/34, nRF=0.176471
Jaccard_LPU : rf=6/34, nRF=0.176471
```

## Name mapping (FASTA → 1967 reference)

The reference tree uses 1967-publication names; the FASTA uses modern names. The runner applies this remap to query trees before computing nRF:

| FASTA name | Reference name |
|------------|----------------|
| Human | Man |
| Rhesus_monkey | Monkey |
| Pekin_duck | Duck |
| Snapping_turtle | Turtle |
| Rattlesnake | Snake |
| Screwworm_fly | Screw_worm |
| Silkworm_moth | Moth |

## Reproducibility note

K=100 mean-distance averaging compresses the per-pair Dice and Jaccard standard error to ≤ 4×10⁻³, and all four LP variants give the same topology each time at K=30 (3/30 unique). The reported nRF values match the manuscript exactly.
