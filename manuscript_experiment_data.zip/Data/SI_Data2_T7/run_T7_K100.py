#!/usr/bin/env python3
"""Reproduce the T7 (Hillis 1994) LP four-tree analysis reported in Figure 4
and the main-paper T7 nRF rows using lp_developers v2.0.18 with K=100
mean-distance averaging.

Pipeline:
  1) Load 9 sequences (J, K, L, M, N, O, P, Q, R) from hillis_1994.fasta.
  2) Run K=100 independent get_ladderpath calls. For each, derive Dice and
     Jaccard distance tables via ladderpath_tools.species_distance.
  3) Average all K=100 distance tables per pair.
  4) Build NJ and UPGMA trees on the mean Dice and Jaccard matrices via
     ladderpath_tools.phylo.phylo.
  5) Re-root each tree on the outgroup 'R' and compute rooted nRF against
     hillis_1994_reference.newick.

Expected nRF values (matches main-paper Section 3.1 and Figure 4):
    Dice_LPN     0.143
    Dice_LPU     0.000
    Jaccard_LPN  0.143
    Jaccard_LPU  0.000
"""

import csv
import sys
import time
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import numpy as np

LP_DEVELOPERS_ROOT = "/Document/results"
sys.path.insert(0, LP_DEVELOPERS_ROOT)

from lp_developers import ladderpath as lp
from lp_developers.ladderpath_tools import phylo as lp_phylo
from lp_developers.ladderpath_tools import species_distance as lp_sd
from Bio import SeqIO
from ete3 import Tree

HERE = Path(__file__).resolve().parent
FASTA = HERE / "hillis_1994.fasta"
REF = HERE / "hillis_1994_reference.newick"
OUTGROUP = "R"
K = 100


def clean_seq(seq):
    return "".join(ch for ch in str(seq).upper() if ch not in {"-", " ", "\t", "\n", "\r"})


def main():
    records = list(SeqIO.parse(str(FASTA), "fasta"))
    labels = [r.id for r in records]
    seqs = [clean_seq(r.seq) for r in records]
    N = len(seqs)
    print(f"T7: N={N}, labels={labels}, length={len(seqs[0])} (uniform)")

    target_ids = [-(i + 1) for i in range(N)]
    species_info = {f"sp{i+1}": (labels[i], [target_ids[i]]) for i in range(N)}

    print(f"running K={K} LP iterations...")
    dice_runs, jacc_runs, lp_idx = [], [], []
    t0 = time.time()
    for k in range(1, K + 1):
        lpjson = lp.get_ladderpath(seqs, save_file_name=None, show_version=False, gpu_mode=0)
        lp_idx.append(lpjson["ladderpath-index"])
        d, nm, _ = lp_sd.get_distance_table(lpjson, species_info, method="dice", verbose=False)
        j, _, _ = lp_sd.get_distance_table(lpjson, species_info, method="jaccard", verbose=False)
        dice_runs.append({kk: max(0.0, float(v)) for kk, v in d.items()})
        jacc_runs.append({kk: max(0.0, float(v)) for kk, v in j.items()})
        if k == 1 or k % 25 == 0 or k == K:
            print(f"  run {k:>3d}/{K}: LP={lpjson['ladderpath-index']}, elapsed {time.time()-t0:.1f}s")

    pair_keys = list(dice_runs[0].keys())
    dice_mean = {pk: float(np.mean([r[pk] for r in dice_runs])) for pk in pair_keys}
    jacc_mean = {pk: float(np.mean([r[pk] for r in jacc_runs])) for pk in pair_keys}
    name_map = {int(k): v for k, v in nm.items()}

    cv = float(np.std(lp_idx, ddof=1) / np.mean(lp_idx))
    print(f"K={K} done; LP-index mean={np.mean(lp_idx):.2f}, CV={cv:.4f}")

    ref = Tree(str(REF), format=1)
    ref.set_outgroup(OUTGROUP)
    specs = [
        ("Dice_LPN",    dice_mean, "nj"),
        ("Dice_LPU",    dice_mean, "upgma"),
        ("Jaccard_LPN", jacc_mean, "nj"),
        ("Jaccard_LPU", jacc_mean, "upgma"),
    ]
    print(f"\nrooted nRF vs reference (outgroup='{OUTGROUP}'):")
    for label, table, algo in specs:
        tmp = HERE / f"_tmp_{label}.newick"
        if tmp.exists(): tmp.unlink()
        lp_phylo.phylo(table, name_map, method=algo, outgroup_name=None,
                       newick_file_name=str(tmp), fig_file_name=None,
                       show_plot=False, verbose=False)
        q = Tree(str(tmp), format=1)
        q.set_outgroup(OUTGROUP)
        rf, max_rf, *_ = ref.robinson_foulds(q, unrooted_trees=False)
        nrf = rf / max_rf if max_rf else 0.0
        print(f"  {label:<12}: rf={rf}/{max_rf}, nRF={nrf:.6f}")
        tmp.unlink()


if __name__ == "__main__":
    main()
