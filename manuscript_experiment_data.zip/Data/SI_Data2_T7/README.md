# SI Data 2 — Bacteriophage T7 (Hillis 1994) dataset

This bundle contains the input sequences, reference tree, runner script, and Ladderpath tree outputs for the T7 empirical analysis reported in Section 3.1 and Figure 4 of the main paper.

## Files

| file | description |
|------|-------------|
| `hillis_1994.fasta` | 9 unaligned T7 sequences (taxa J, K, L, M, N, O, P, Q, R), length 1,091 nt each. |
| `hillis_1994_reference.newick` | Experimentally recorded T7 lineage `(R,((J,M),(K,L)),((N,Q),(O,P)));` used as the rooted-nRF reference. R is the outgroup. |
| `T7_Dice_LPN.newick`, `T7_Dice_LPU.newick`, `T7_Jaccard_LPN.newick`, `T7_Jaccard_LPU.newick` | LP trees built from the K=100 mean distance matrices, before rerooting. |
| `T7_Dice_LPN_rooted_R.newick`, `T7_Dice_LPU_rooted_R.newick`, `T7_Jaccard_LPN_rooted_R.newick`, `T7_Jaccard_LPU_rooted_R.newick` | Same trees after `set_outgroup('R')`. These are the trees fed into the rooted-nRF computation. |
| `T7_pair_distances_K100.csv` | Per-pair Dice and Jaccard mean ± SE over K=100 independent LP runs. |
| `T7_nRF_summary_K100.csv` | Rooted nRF, rf, and max_rf for the four LP variants against the reference. |
| `run_T7_K100.py` | One-file runner that reproduces all of the above from `hillis_1994.fasta` + `hillis_1994_reference.newick`. |

## Reproducing the T7 nRF values

```
python3 run_T7_K100.py
```

Expected output (matches Section 3.1 and Figure 4 of the main paper):

```
Dice_LPN    : rf=2/14, nRF=0.142857
Dice_LPU    : rf=0/14, nRF=0.000000
Jaccard_LPN : rf=2/14, nRF=0.142857
Jaccard_LPU : rf=0/14, nRF=0.000000
```

## Reproducibility note

The T7 result is robust to single-LP-run variability: 10 independent runs without averaging give bit-identical rooted nRF for each method (Dice_LPN = Jaccard_LPN = 0.143, Dice_LPU = Jaccard_LPU = 0.000). The K=100 mean-distance averaging used here further compresses the per-pair distance standard error to ≤ 5×10⁻⁴, well below any topology-sensitive threshold.
